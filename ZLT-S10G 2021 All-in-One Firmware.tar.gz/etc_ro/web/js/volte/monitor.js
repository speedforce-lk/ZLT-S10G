define([ 'jquery', 'knockout', 'config/config', 'service', 'underscore' ], 
function($, ko, config, service, _) {
    var arrForm1 = ["frmStaticIpSwitch","frmStaticIpSwitchDiv","frmStaticIpSwitchClass"];
    var arrForm2 = ["static_ip_mac","static_ip_macDiv","static_ip_macClass"];
    function DdnsViewModel(){
        var self = this;
        var info = service.getMonitor();
        creatForm(arrForm1,arrForm2);
        self.port_settings = ko.observable(info.siproxd_enable = "" ? "0" : info.siproxd_enable);
        self.port = ko.observable(info.sip_listen_port);
        self.staticIpHandle = function(enable){
            enable == '1' ? $("#staticIpDiv").show() : $("#staticIpDiv").hide();
            return true;
        }
        self.isShowStaticIpDiv =ko.observable(self.port_settings() == "1");
         self.save = function() {
            showLoading('waiting');
            service.monitorSettings({
                enable:self.port_settings(),
                sip_listen_port:self.port()
            }, function(result) {
                if (result.result == "success") {
                    showConfirm("reboot_tips", function(){
                        showLoading("restarting");
                        service.restart({}, function (data) {
                            if (data && data.result == "success") {
                                successOverlay();
                            } else {
                                errorOverlay();
                            }
                        }, $.noop);
                    });
                } else {
                    errorOverlay();
                }
            });
        }
        self.submitApply = function(){

             self.save();
        }
        service.bindCommonData(self);
        
       var params = {};
            params.goformId = "SET_VOLTE_STATUS";
            service.setVolteStatus(params, function(data){
        });
}
    /**
     * 初始化
     * @method init
     */
    function init() {
        if(this.init){
            getRightNav(VOLTE_SETTINGS_URL);
            getInnerHeader(INNER_HEADER_COMMON_URL);
        }
        var container = $('#container');
        ko.cleanNode(container[0]);
        var vm = new DdnsViewModel();
        ko.applyBindings(vm, container[0]);
    }
    
    return {
        init: init
    };
});