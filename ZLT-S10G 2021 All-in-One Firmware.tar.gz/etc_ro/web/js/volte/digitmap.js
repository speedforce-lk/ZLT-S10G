/** 
 * DDNS设置模块
 * @module DDNS
 * @class DDNS
 */
define([ 'jquery', 'knockout', 'config/config', 'service', 'underscore' ],
function($, ko, config, service, _) {
    /**
     * DDNS设置view model
     * @class ddnsViewModel
     */
     var arrForm1 = ["frmStaticIpSwitch","frmStaticIpSwitchDiv","frmStaticIpSwitchClass"]; 
     var arrForm2 = ["static_ip_mac","static_ip_macDiv","static_ip_macClass"];
    function DdnsViewModel(){
        var self = this;
        var info = service.getAllOnceDatas();
        self.port_settings = ko.observable(info.digitmap_switch = "" ? "0" : info.digitmap_switch);
        self.port = ko.observable(info.digitmap_str);
        self.staticIpHandle = function(enable){
            enable == '1' ? $("#staticIpDiv").show() : $("#staticIpDiv").hide();
            return true;
        }
        creatForm(arrForm1,arrForm2);
        self.isShowStaticIpDiv =ko.observable(self.port_settings() == "1");
         self.save = function() {
            showLoading('waiting');
            service.digitmapSettings({
                digitmap_switch:self.port_settings(),
                digitmap_str:self.port()
            }, function(result) {
                if (result.result == "success") {
                      successOverlay();
                           
                } else {
                    errorOverlay();
                }
            });
        }
        self.submitApply = function(){

             self.save();
        }
        service.bindCommonData(self);
        
}
    /**
     * 初始化
     * @method init
     */
    function init() {
        if(this.init){
            getRightNav(VOLTE_SETTINGS_URL);
            getInnerHeader(INNER_HEADER_COMMON_URL);
        }
        var container = $('#container');
        ko.cleanNode(container[0]);
        var vm = new DdnsViewModel();
        ko.applyBindings(vm, container[0]);
    }
    
    return {
        init: init
    };
});