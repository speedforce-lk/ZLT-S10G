/** 
 * DDNS设置模块
 * @module DDNS
 * @class DDNS
 */
define([ 'jquery', 'knockout', 'config/config', 'service', 'underscore' ],
function($, ko, config, service, _) {

    var arrForm1 = ["sipServerButton","sipServerButtonDiv","sipServerButtonClass"];
    var arrForm2 = ["ddnsForm","ddnsFormDiv","ddnsFormClass"];
	function DdnsViewModel(){
        var self=this;
        service.bindCommonData(self);
        var tz_voice_type = service.voiceCallType().tz_voice_type;
        $(".form-control").val(tz_voice_type);
        creatForm(arrForm1,arrForm2);
            var info = service.getSipServerData();
            self.sip_reg_server = ko.observable(info.sip_reg_server);
            self.sip_reg_port = ko.observable(info.sip_reg_port);
            self.sip_domain_address = ko.observable(info.sip_domain_address);
            self.sip_domain_port = ko.observable(info.sip_domain_port);
            self.sip_proxy_address = ko.observable(info.sip_proxy_address);
            self.sip_proxy_port = ko.observable(info.sip_proxy_port);
            self.sip_proxy_enable = ko.observable(info.sip_proxy_enable == "1");
            self.sip_display_name = ko.observable(info.sip_display_name);
            self.sip_user_name = ko.observable(info.sip_user_name);
            self.sip_reg_account = ko.observable(info.sip_reg_account);
            self.sip_reg_pwd = ko.observable(info.sip_reg_pwd);
            self.hasWifi = ko.observable(config.HAS_WIFI);
            self.isShowSip = ko.observable(false);
            if(tz_voice_type == "1"){
                self.isShowSip(true);
             }else{
                self.isShowSip(false);
             }
            setInterval(function(){
                status();
            },3000);

            function status(){
                if(info.voip_reg_st  == "1"){
                    $("#voip_reg_st").attr('data-trans', 'register_connecting');
                }else if(info.voip_reg_st  == "2"){
                    $("#voip_reg_st").attr('data-trans', 'register_failed');
                }else if(info.voip_reg_st  == "3"){
                    $("#voip_reg_st").attr('data-trans', 'register_success');
                }else{
                    $("#voip_reg_st").attr('data-trans', 'volte_Unregistered');
                }
                if(info.voip_auth_st  == "1"){
                    $("#voip_auth_st").attr('data-trans', 'authorization_state_1');
                }else if(info.voip_auth_st  == "2"){
                    $("#voip_auth_st").attr('data-trans', 'authorization_state_2');
                }else if(info.voip_auth_st  == "3"){
                    $("#voip_auth_st").attr('data-trans', 'authorization_state_3');
                }else{
                    $("#voip_auth_st").attr('data-trans', 'authorization_state_4');
                }
            }
             status();
            self.save = function() {
            var params = {};
            params.goformId = "TZ_VOICE_TYPE";
            params.tz_voice_type = $(".form-control").val();
            showLoading('waiting');
            service.setVoiceCallType(params, function(result) {
                if (result.result == "success") {
                    var tz_voice_type = service.voiceCallType().tz_voice_type;
                        if(tz_voice_type == "1"){
                            self.isShowSip(true);
                            successOverlay();
                         }else{
                            self.isShowSip(false);
                            showConfirm("reboot_tips", function () {
                                showLoading("restarting");
                                service.restart({}, function (data) {
                                    if (data && data.result == "success") {
                                        successOverlay();
                                    } else {
                                        errorOverlay();
                                    }
                                }, $.noop);
                            });
                       }                                        

                } else {
                    errorOverlay();
                }
            });
        }

         self.saveAct = function() {
                showLoading();
                var params = {
                    sip_reg_server: self.sip_reg_server(),
                    sip_reg_port: self.sip_reg_port(),
                    sip_domain_address: self.sip_domain_address(),
                    sip_domain_port: self.sip_domain_port(),
                    sip_proxy_address: self.sip_proxy_address(),
                    sip_proxy_port: self.sip_proxy_port(),
                    sip_proxy_enable: self.sip_proxy_enable() == true ? "1" :"0",
                    sip_display_name: self.sip_display_name(),
                    sip_user_name: self.sip_user_name(),
                    sip_reg_account: self.sip_reg_account(),
                    sip_reg_pwd: self.sip_reg_pwd(),
                    CSRFToken: self.CSRFToken
                };
                service.setSipServer(params, function(result) {
                    if (result.result == "success") {
                 showConfirm("reboot_tips", function () {
                    showLoading("restarting");
                    service.restart({}, function (data) {
                        if (data && data.result == "success") {
                            successOverlay();
                        } else {
                            errorOverlay();
                        }
                    }, $.noop);
                });
                    } else {
                        errorOverlay();
                    }
                });
            };
}
    /**
     * 初始化
     * @method init
     */
	function init() {
		if(this.init){
            getRightNav(VOLTE_SETTINGS_URL);
            getInnerHeader(INNER_HEADER_COMMON_URL);
        }
		var container = $('#container');
		ko.cleanNode(container[0]);
		var vm = new DdnsViewModel();
		ko.applyBindings(vm, container[0]);
        $('#ddnsForm').validate({
            submitHandler:function () {
                vm.save();
            }
        });
        $('#sipServerButton').validate({
            submitHandler:function () {
                vm.saveAct();
            },
            rules:{
                    txtDestPort1: {
                    digits: true,
                    range: [1, 65535]
                    },
                    txtDestPort2: {
                    digits: true,
                    range: [1, 65535]
                    },
                    txtDestPort3: {
                    digits: true,
                    range: [1, 65535]
                    }
                }
        });
	
    }
    
    return {
        init: init
    };
});