/** 
 * Router设置
 * @module lan
 * @class lan
 */
define([ 'jquery', 'knockout', 'config/config', 'service','underscore'],
    function ($, ko, config, service) {
	var originfrmLan="";
    var arrForm = ["frmLan","frmLanDiv","frmLanClass"];
        function LanVM() {
            var self = this;

            var info = service.getSipServerData();
            self.sip_reg_server = ko.observable(info.sip_reg_server);
            self.sip_reg_port = ko.observable(info.sip_reg_port);
            self.sip_domain_address = ko.observable(info.sip_domain_address);
            self.sip_domain_port = ko.observable(info.sip_domain_port);
            self.sip_proxy_address = ko.observable(info.sip_proxy_address);
            self.sip_proxy_port = ko.observable(info.sip_proxy_port);
            self.sip_proxy_enable = ko.observable(info.sip_proxy_enable == "1");
            self.sip_display_name = ko.observable(info.sip_display_name);
            self.sip_user_name = ko.observable(info.sip_user_name);
            self.sip_reg_account = ko.observable(info.sip_reg_account);
            self.sip_reg_pwd = ko.observable(info.sip_reg_pwd);
            self.hasWifi = ko.observable(config.HAS_WIFI);
            creatForm(arrForm);
            setInterval(function(){
                status();
            },3000);

            function status(){
                if(info.voip_reg_st  == "1"){
                    $("#voip_reg_st").attr('data-trans', 'register_connecting');
                }else if(info.voip_reg_st  == "2"){
                    $("#voip_reg_st").attr('data-trans', 'register_failed');
                }else if(info.voip_reg_st  == "3"){
                    $("#voip_reg_st").attr('data-trans', 'register_success');
                }else{
                    $("#voip_reg_st").attr('data-trans', 'volte_Unregistered');
                }
                if(info.voip_auth_st  == "1"){
                    $("#voip_auth_st").attr('data-trans', 'authorization_state_1');
                }else if(info.voip_auth_st  == "2"){
                    $("#voip_auth_st").attr('data-trans', 'authorization_state_2');
                }else if(info.voip_auth_st  == "3"){
                    $("#voip_auth_st").attr('data-trans', 'authorization_state_3');
                }else{
                    $("#voip_auth_st").attr('data-trans', 'authorization_state_4');
                }
            }
             status();
            service.bindCommonData(self);
           
            self.saveAct = function() {
                showLoading();
                var params = {
                    sip_reg_server: self.sip_reg_server(),
                    sip_reg_port: self.sip_reg_port(),
                    sip_domain_address: self.sip_domain_address(),
                    sip_domain_port: self.sip_domain_port(),
                    sip_proxy_address: self.sip_proxy_address(),
                    sip_proxy_port: self.sip_proxy_port(),
                    sip_proxy_enable: self.sip_proxy_enable() == true ? "1" :"0",
                    sip_display_name: self.sip_display_name(),
                    sip_user_name: self.sip_user_name(),
                    sip_reg_account: self.sip_reg_account(),
                    sip_reg_pwd: self.sip_reg_pwd(),
                    CSRFToken: self.CSRFToken
                };
                service.setSipServer(params, function(result) {
                    if (result.result == "success") {
                        successOverlay();
                    } else {
                        errorOverlay();
                    }
                });
            };
}
        /**
         * 初始化
         * @method init
         */
        function init() {
            if(this.init){
               getRightNav(VOLTE_SETTINGS_URL);
                getInnerHeader(INNER_HEADER_COMMON_URL);
            }

            var container = $('#container');
            ko.cleanNode(container[0]);
            var vm = new LanVM();
            ko.applyBindings(vm, container[0]);

            $('#frmLan').validate({
                submitHandler:function () {
                    vm.saveAct();
                },
                rules:{
                    txtDestPort1: {
                    digits: true,
                    range: [1, 65535]
                    },
                    txtDestPort2: {
                    digits: true,
                    range: [1, 65535]
                    },
                    txtDestPort3: {
                    digits: true,
                    range: [1, 65535]
                    }
                }
            });

        }
        return {
            init:init
        }
    }
);
