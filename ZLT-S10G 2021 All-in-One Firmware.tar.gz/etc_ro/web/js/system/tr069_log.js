/** 
 * Created by hewq on 18/04/17.
 */
define(['jquery', 'knockout', 'config/config', 'service', 'underscore'],

    function ($, ko, config, service, _) {

        function tr069LogVm(){
                var self = this;
                 service.bindCommonData(self);
                 $("#stop").attr("disabled",true);
                 $("#export").attr("disabled",true);
                 self.start = function(){
                    setLog("start");
                 };
                 self.exportBtn = function(){
                    setLog("export");
                 }
                 self.stop = function(){
                    setLog("stop"); 
                 }
            }
            function setLog(operation){
                showLoading('waiting');
                var params = {};
                params.cmd = "tr069_log";
                params.operation = operation;
                service.tr069Log(params, function(data){
                   setTimeout(function(){
                     if(data.tr069_start == "success"){
                        $("#stop").attr("disabled",false);
                        $("#export").attr("disabled",true);
                         successOverlay();
                    }else if(data.tr069_stop == "success"){
                        $("#start").attr("disabled",true);
                        $("#export").attr("disabled",false);
                         successOverlay();
                    }else if(data.tz_tr069_log == "success"){  
                        $("#downloadURL").show(0);
                        $('#downloadURL').attr("download","tr069_log.tar.gz");
                        $("#downloadURL").attr("href","tr069_log.tar.gz");
                        $("#start").attr("disabled",false);
                        $("#stop").attr("disabled",true);
                        successOverlay();
                    }else{
                        errorOverlay();
                    }
                   },5000);
                }); 
            }



        /**
         * 初始化 ViewModel，并进行绑定
         * @method init
         */
        function init() {
            if(this.init){
                getRightNav(SYSTEM_SETTINGS_COMMON_URL);
                getTabsNav(NETWORK_TOOLS_COMMON_URL);
                getInnerHeader(INNER_HEADER_COMMON_URL);
            }

            var container = $('#container');
            ko.cleanNode(container[0]);
            var vm = new tr069LogVm();
            ko.applyBindings(vm, container[0]);
        }

        return {
            init: init
        }
    });

