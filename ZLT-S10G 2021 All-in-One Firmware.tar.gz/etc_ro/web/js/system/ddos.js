/** 
 * @module system_security
 * @class system_security
 */
define([ 'jquery', 'knockout', 'config/config', 'service', 'underscore' ],

function($, ko, config, service, _) {
    var arrForm = ["sysSecurityForm","sysSecurityFormDiv","sysSecurityFormClass"];
	function SysSecurityModeVM() {
        var self = this;
        var info = service.getDdosStatus();
        self.ddosProtectionFlag = ko.observable(info.ddosProtectionFlag);
        service.bindCommonData(self);
        self.clear = function() {
            init();
        };
        creatForm(arrForm);
        self.save = function() {
            showLoading();
            var params = {};
            params.ddosProtectionFlag = self.ddosProtectionFlag();
            service.setDdosStatus(params, function(result) {
                if (result.result == "success") {
                    successOverlay();
                } else {
                    errorOverlay();
                }
            });

        };
    }

	function init() {
	    if(this.init){
            getRightNav(FIREWALL_COMMON_URL);
            getInnerHeader(INNER_HEADER_COMMON_URL);
        }

		var container = $('#container');
		ko.cleanNode(container[0]);
		var vm = new SysSecurityModeVM();
		ko.applyBindings(vm, container[0]);
        $('#sysSecurityForm').validate({
            submitHandler : function() {
                vm.save();
            }
        });
	}

	return {
		init : init
	};
});