/** 
 * others 模块
 * @module others:Restart and Reset、Turn Off Device、Fast Boot Settings、SNTP、PIN Management
 * @class others
 */

define(['jquery', 'knockout', 'config/config', 'service', 'underscore'],

    function ($, ko, config, service, _) {
        /**
         * othersViewModel
         * @class othersVM
         */
        function othersVM() {
            var self = this;
            service.bindCommonData(self);
           
            /**
             * 重启
             * @method restart
             */
            self.restart = function () {
                showConfirm("restart_confirm", function () {
                    showLoading("restarting");
                    service.restart({}, function (data) {
                        if (data && data.result == "success") {
                            successOverlay();
                        } else {
                            errorOverlay();
                        }
                    }, $.noop);
                });
            };
}
        /**
         * 初始化 ViewModel，并进行绑定
         * @method init
         */
        function init() {
            if(this.init){
                getRightNav(SYSTEM_SETTINGS_COMMON_URL);
                getInnerHeader(INNER_HEADER_COMMON_URL);
            }
            var vm = new othersVM();
            ko.applyBindings(vm, $('#container')[0]);
        }

        return {
            init: init
        }
    });
